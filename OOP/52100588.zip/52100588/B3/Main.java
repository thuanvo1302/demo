public class Main {
    public static void main(String[] args){
        HocSinh a = new HocSinh("NguyenHuyHoa",10,9.2,9.1);
        HocSinh b = new HocSinhChuyenVan("NguyenHuyHoa",10,9.2,9.1,"C001");
        System.out.println(a);
        System.out.println(b);
    }   
}
